#!/usr/bin/env python3
"""
Mission Coordinator — 2대 로봇 에스코트 미션 관리 (단일 인스턴스)

실행:
  ros2 run state_manager mission_coordinator

설정값(핸드오버 구역 좌표)은 아래 HANDOVER_ZONES 딕셔너리에서 수정.

핸드오버 구역 구조:
  구역 1, 2가 있고 각 구역에 robot2/robot4의 고유 좌표가 따로 존재.
  핸드오버 시 Robot A → 자신의 구역 좌표, Robot B → 자신의 구역 좌표로 동시 이동.
  사용할 구역은 사용자 목적지에서 가장 가까운 구역으로 자동 선택.

미션 흐름:
  PATROL
    → REQUESTED           : /user_request 수신 — 사용자 위치
    → INTERACTING         : Robot A 정지, Robot B 순찰 유지 (구역 미확정)
    → ESCORTING_TO_HANDOVER: /user_destination 수신 — 구역 선택
                              Robot A → 자신의 구역 좌표로 에스코트
                              Robot B → 자신의 구역 좌표로 이동(RESERVE)
    → HANDOVER_WAITING    : Robot A 도착(WAITING_HANDOVER) + Robot B 도착(HANDOVER_READY)
    → ESCORTING_TO_FINAL  : Robot B가 최종 목적지까지 에스코트
    → COMPLETED           : 양쪽 복귀 → PATROL 재시작

외부 토픽:
  /user_request      (PoseStamped)  수신 — 사용자 호출 (pose = 사용자 현재 위치)
  /user_destination  (PoseStamped)  수신 — 사용자 목적지
  /mission_cancel    (String)       수신 — 페이로드 무관, 현재 미션 취소

로봇별 발행:
  /{ns}/cmd_state   (String)       — 상태 명령 (nav_goal보다 나중에 발행)
  /{ns}/nav_goal    (PoseStamped)  — 이동 목적지

전체 발행:
  /mission_state    (String)       — 현재 미션 상태 (1 Hz)
"""

import rclpy
from rclpy.node import Node
from enum import Enum

from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped


# ── 핸드오버 구역 설정 ────────────────────────────────────────────────────────
# 구역번호: { 로봇ID: (x, y) }  — 모두 map 프레임 기준
# robot2가 구역 1로 인계하면 robot4도 구역 1에서 인계받는 구조.
HANDOVER_ZONES: dict[int, dict[str, tuple]] = {
    1: {
        'robot2': (0.0, 0.0),   # 구역 1에서 robot2가 서는 좌표
        'robot4': (0.5, 0.0),   # 구역 1에서 robot4가 서는 좌표
    },
    2: {
        'robot2': (5.0, 0.0),   # 구역 2에서 robot2가 서는 좌표
        'robot4': (5.5, 0.0),   # 구역 2에서 robot4가 서는 좌표
    },
}

_ROBOT_IDS = ('robot2', 'robot4')


class MissionState(Enum):
    PATROL                = 'PATROL'
    REQUESTED             = 'REQUESTED'
    INTERACTING           = 'INTERACTING'
    ASSIGNED              = 'ASSIGNED'
    ESCORTING_TO_HANDOVER = 'ESCORTING_TO_HANDOVER'
    HANDOVER_WAITING      = 'HANDOVER_WAITING'
    ESCORTING_TO_FINAL    = 'ESCORTING_TO_FINAL'
    COMPLETED             = 'COMPLETED'
    CANCELLED             = 'CANCELLED'
    EMERGENCY             = 'EMERGENCY'
    FAILED                = 'FAILED'


class MissionCoordinator(Node):
    def __init__(self):
        super().__init__('mission_coordinator')

        # ── 미션 상태 ────────────────────────────────────────────────────
        self._mission        = MissionState.PATROL
        self._robot_a        = None   # 첫 번째 에스코트 로봇 (사용자 → 핸드오버)
        self._robot_b        = None   # 두 번째 에스코트 로봇 (핸드오버 → 목적지)
        self._destination    = None
        self._handover_zone  = None   # 선택된 핸드오버 구역 번호 (1 또는 2)

        # 로봇별 최신 상태 ('': 아직 미수신)
        self._robot_states: dict[str, str] = {r: '' for r in _ROBOT_IDS}

        # ── 퍼블리셔 ─────────────────────────────────────────────────────
        self._cmd_pubs = {
            r: self.create_publisher(String,      f'/{r}/cmd_state', 10)
            for r in _ROBOT_IDS
        }
        self._nav_pubs = {
            r: self.create_publisher(PoseStamped, f'/{r}/nav_goal',  10)
            for r in _ROBOT_IDS
        }
        self._mission_pub = self.create_publisher(String, '/mission_state', 10)

        # ── 서브스크립션 ─────────────────────────────────────────────────
        for r in _ROBOT_IDS:
            self.create_subscription(
                String, f'/{r}/robot_state',
                lambda msg, rid=r: self._on_robot_state(rid, msg), 10)

        self.create_subscription(PoseStamped, '/user_request',    self._on_user_request, 10)
        self.create_subscription(PoseStamped, '/user_destination', self._on_user_dest,   10)
        self.create_subscription(String,      '/mission_cancel',   self._on_cancel,      10)

        self.create_timer(1.0, self._publish_mission_state)
        self.get_logger().info('MissionCoordinator 준비')

    # ── 로봇 상태 감시 ───────────────────────────────────────────────────
    def _on_robot_state(self, robot_id: str, msg: String):
        prev = self._robot_states.get(robot_id, '')
        new  = msg.data
        if prev == new:
            return
        self._robot_states[robot_id] = new
        self.get_logger().info(f'[ROBOT] {robot_id}: {prev or "?"} → {new}')
        self._handle_robot_transition(robot_id, prev, new)

    def _handle_robot_transition(self, robot_id: str, prev: str, new: str):
        ms = self._mission

        # PATROL 중 IDLE이 된 로봇 → 순찰 재시작
        if ms == MissionState.PATROL and new == 'IDLE':
            self._cmd(robot_id, 'START_PATROL')
            return

        # Robot A가 핸드오버 지점 도달 (ESCORTING → IDLE)
        if (ms == MissionState.ESCORTING_TO_HANDOVER and
                robot_id == self._robot_a and new == 'IDLE'):
            self._cmd(self._robot_a, 'WAIT_HANDOVER')
            self._set_mission(MissionState.HANDOVER_WAITING)
            return

        # Robot A가 WAITING_HANDOVER 확정 → 핸드오버 조건 체크
        if (ms == MissionState.HANDOVER_WAITING and
                robot_id == self._robot_a and new == 'WAITING_HANDOVER'):
            self._try_handover()
            return

        # Robot B가 핸드오버 구역 도달 (HANDOVER_READY)
        if (new == 'HANDOVER_READY' and
                ms in (MissionState.ESCORTING_TO_HANDOVER,
                       MissionState.HANDOVER_WAITING)):
            if ms == MissionState.HANDOVER_WAITING:
                self._try_handover()
            return

        # Robot B가 최종 목적지 도달 → 미션 완료
        if (ms == MissionState.ESCORTING_TO_FINAL and
                robot_id == self._robot_b and new == 'IDLE'):
            self._set_mission(MissionState.COMPLETED)
            self._on_mission_completed()
            return

        # 비상 상황 → 전체 로봇 정지
        if new == 'EMERGENCY':
            self.get_logger().error(f'[MISSION] {robot_id} EMERGENCY → 전체 정지')
            self._set_mission(MissionState.EMERGENCY)
            for r in _ROBOT_IDS:
                if r != robot_id:
                    self._cmd(r, 'EMERGENCY')

    def _try_handover(self):
        """Robot A 대기 중 + Robot B 준비 완료 시 핸드오버 실행."""
        if self._mission != MissionState.HANDOVER_WAITING:
            return
        a_waiting = self._robot_states.get(self._robot_a) == 'WAITING_HANDOVER'
        b_ready   = self._robot_states.get(self._robot_b) == 'HANDOVER_READY'
        if not (a_waiting and b_ready):
            self.get_logger().info(
                f'[HANDOVER] 대기 중  '
                f'A={self._robot_states.get(self._robot_a)}  '
                f'B={self._robot_states.get(self._robot_b)}')
            return

        self.get_logger().warn('[HANDOVER] 조건 충족 → 핸드오버 실행')
        # Robot A: 핸드오버 완료, 홈 복귀
        self._cmd(self._robot_a, 'HANDOVER_DONE')
        # Robot B: 최종 목적지로 에스코트
        if self._destination:
            self._nav(self._robot_b, self._destination)
        self._cmd(self._robot_b, 'START_ESCORT')
        self._set_mission(MissionState.ESCORTING_TO_FINAL)

    # ── 외부 입력 처리 ───────────────────────────────────────────────────
    def _on_user_request(self, msg: PoseStamped):
        if self._mission != MissionState.PATROL:
            self.get_logger().warn('[MISSION] 요청 무시 (PATROL 상태가 아님)')
            return

        self._set_mission(MissionState.REQUESTED)
        robot_a, robot_b = self._assign_robots()
        if robot_a is None:
            self.get_logger().error('[MISSION] 사용 가능한 로봇 없음 → FAILED')
            self._set_mission(MissionState.FAILED)
            return

        self._robot_a = robot_a
        self._robot_b = robot_b
        self.get_logger().warn(f'[MISSION] 배정  A={robot_a}  B={robot_b}')

        # Robot A: 순찰 중단, 사용자와 목적지 입력 대기
        self._cmd(self._robot_a, 'INTERACT')
        # Robot B: 목적지를 모르는 상태이므로 순찰 유지 (구역 선택 후 이동)

        self._set_mission(MissionState.INTERACTING)

    def _on_user_dest(self, msg: PoseStamped):
        if self._mission != MissionState.INTERACTING:
            self.get_logger().warn('[MISSION] 목적지 무시 (INTERACTING 상태가 아님)')
            return

        self._destination   = msg
        self._handover_zone = self._select_handover_zone(msg)
        self.get_logger().warn(
            f'[MISSION] 목적지 설정  '
            f'({msg.pose.position.x:.2f}, {msg.pose.position.y:.2f})  '
            f'→ 핸드오버 구역 {self._handover_zone} 선택')

        # 구역 확정 후 양쪽 로봇을 각자의 구역 좌표로 동시 출발
        # nav_goal → cmd 순서 보장 (버퍼링 구조)
        self._nav(self._robot_a, self._zone_pose(self._robot_a))
        self._cmd(self._robot_a, 'START_ESCORT')

        if self._robot_b:
            self._nav(self._robot_b, self._zone_pose(self._robot_b))
            self._cmd(self._robot_b, 'RESERVE')

        self._set_mission(MissionState.ESCORTING_TO_HANDOVER)

    def _on_cancel(self, msg: String):
        if self._mission in (MissionState.PATROL, MissionState.CANCELLED,
                             MissionState.COMPLETED):
            return
        self.get_logger().warn('[MISSION] 미션 취소')
        for r in _ROBOT_IDS:
            self._cmd(r, 'RETURN_HOME')
        self._reset_mission()
        self._set_mission(MissionState.PATROL)
        # 이미 IDLE인 로봇은 _handle_robot_transition에서 START_PATROL 수신

    # ── 미션 완료 ────────────────────────────────────────────────────────
    def _on_mission_completed(self):
        self.get_logger().warn('[MISSION] 완료 → 복귀 후 PATROL 재개')
        # Robot B 홈 복귀 (Robot A는 HANDOVER_DONE에서 이미 복귀 중)
        self._cmd(self._robot_b, 'RETURN_HOME')
        self._reset_mission()
        self._set_mission(MissionState.PATROL)
        # 이미 IDLE 상태인 로봇에게 즉시 START_PATROL
        for r in _ROBOT_IDS:
            if self._robot_states[r] == 'IDLE':
                self._cmd(r, 'START_PATROL')

    def _reset_mission(self):
        self._robot_a       = None
        self._robot_b       = None
        self._destination   = None
        self._handover_zone = None

    # ── 핸드오버 구역 선택 ───────────────────────────────────────────────
    def _select_handover_zone(self, destination: PoseStamped) -> int:
        """목적지에 가장 가까운 구역 선택 (각 구역의 두 로봇 좌표 중점 기준)."""
        dx = destination.pose.position.x
        dy = destination.pose.position.y
        best_zone, best_dist = None, float('inf')
        for zone_id, coords in HANDOVER_ZONES.items():
            cx = sum(xy[0] for xy in coords.values()) / len(coords)
            cy = sum(xy[1] for xy in coords.values()) / len(coords)
            dist = ((cx - dx) ** 2 + (cy - dy) ** 2) ** 0.5
            if dist < best_dist:
                best_dist = dist
                best_zone = zone_id
        return best_zone

    def _zone_pose(self, robot_id: str) -> PoseStamped:
        """현재 선택된 구역에서 해당 로봇이 서야 하는 좌표 반환."""
        x, y = HANDOVER_ZONES[self._handover_zone][robot_id]
        return _make_pose(x, y)

    # ── 로봇 배정 ────────────────────────────────────────────────────────
    def _assign_robots(self) -> tuple:
        """
        Robot A (첫 에스코트)와 Robot B (핸드오버 로봇) 배정.
        현재: 가용 로봇 중 첫 번째 = A, 두 번째 = B.
        TODO: /{ns}/pose 토픽으로 실제 위치 구독 후 사용자와의 거리 기반 선택으로 개선.
        """
        available = [r for r in _ROBOT_IDS
                     if self._robot_states[r] in ('PATROL', 'IDLE')]
        if not available:
            return None, None
        robot_a = available[0]
        robot_b = available[1] if len(available) > 1 else None
        return robot_a, robot_b

    # ── 공통 유틸 ────────────────────────────────────────────────────────
    def _cmd(self, robot_id: str, command: str):
        msg      = String()
        msg.data = command
        self._cmd_pubs[robot_id].publish(msg)
        self.get_logger().info(f'[CMD] → {robot_id}: {command}')

    def _nav(self, robot_id: str, pose: PoseStamped):
        self._nav_pubs[robot_id].publish(pose)
        self.get_logger().info(
            f'[NAV] → {robot_id}:  '
            f'({pose.pose.position.x:.2f}, {pose.pose.position.y:.2f})')

    def _set_mission(self, new_state: MissionState):
        if self._mission == new_state:
            return
        self.get_logger().warn(f'[MISSION] {self._mission.value} → {new_state.value}')
        self._mission = new_state

    def _publish_mission_state(self):
        msg      = String()
        msg.data = self._mission.value
        self._mission_pub.publish(msg)


def _make_pose(x: float, y: float, frame: str = 'map') -> PoseStamped:
    p = PoseStamped()
    p.header.frame_id    = frame
    p.pose.position.x    = x
    p.pose.position.y    = y
    p.pose.orientation.w = 1.0
    return p


def main(args=None):
    rclpy.init(args=args)
    node = MissionCoordinator()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
