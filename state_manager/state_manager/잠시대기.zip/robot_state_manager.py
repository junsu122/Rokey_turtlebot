#!/usr/bin/env python3
"""
TurtleBot4 Robot State Manager  (robot2 + robot4 동시 실행)

실행:
  ros2 run state_manager robot_state_manager

설정값(홈 좌표, 순찰 경유지)은 아래 ROBOT_CONFIGS 딕셔너리에서 수정.

Commands received on /{ns}/cmd_state (std_msgs/String):
  START_PATROL   — IDLE → PATROL (PATROL_WAYPOINTS 순환)
  STOP_PATROL    — PATROL → IDLE
  INTERACT       — PATROL/IDLE → INTERACTING (제자리 정지)
  RESERVE        — PATROL/IDLE → RESERVED (nav_goal = 핸드오버 지점으로 이동)
  START_ESCORT   — INTERACTING/HANDOVER_READY/IDLE → ESCORTING (nav_goal 목적지로 이동)
  WAIT_HANDOVER  — ESCORTING/IDLE → WAITING_HANDOVER (정지 대기)
  HANDOVER_DONE  — WAITING_HANDOVER → RETURNING (홈으로 복귀)
  RETURN_HOME    — 대부분 상태 → RETURNING (홈으로 복귀)
  EMERGENCY      — 모든 상태 → EMERGENCY (즉시 정지)
  RESET          — EMERGENCY/ERROR → IDLE

Nav goals received on /{ns}/nav_goal (geometry_msgs/PoseStamped):
  _pending_nav_goal에 버퍼링 후, 다음 명령에서 사용.
  ESCORTING 중에 수신하면 즉시 목적지 변경.
"""

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor
from enum import Enum

from std_msgs.msg import String
from std_srvs.srv import Empty
from geometry_msgs.msg import PoseStamped, Twist
from nav2_msgs.action import NavigateToPose

try:
    from irobot_create_msgs.msg import DockStatus, HazardDetectionVector, HazardDetection
    _HAS_IROBOT = True
except ImportError:
    _HAS_IROBOT = False


# ── 로봇별 설정 ────────────────────────────────────────────────────────────
# 홈 좌표와 순찰 경유지(map 프레임 x,y 쌍)를 여기서 수정하세요.
ROBOT_CONFIGS: dict[str, dict] = {
    'robot2': {
        'home_x': 0.0,
        'home_y': 0.0,
        'patrol_waypoints': [1.0, 0.0,  2.0, 1.0,  0.0, 2.0],  # x0,y0, x1,y1, ...
    },
    'robot4': {
        'home_x': 3.0,
        'home_y': 0.0,
        'patrol_waypoints': [4.0, 0.0,  5.0, 1.0,  3.0, 2.0],
    },
}


class RobotState(Enum):
    UNDOCKING        = 'UNDOCKING'
    IDLE             = 'IDLE'
    PATROL           = 'PATROL'
    INTERACTING      = 'INTERACTING'
    RESERVED         = 'RESERVED'
    HANDOVER_READY   = 'HANDOVER_READY'
    ESCORTING        = 'ESCORTING'
    WAITING_HANDOVER = 'WAITING_HANDOVER'
    RETURNING        = 'RETURNING'
    EMERGENCY        = 'EMERGENCY'
    ERROR            = 'ERROR'


class RobotStateManager(Node):
    def __init__(self, robot_id: str, config: dict):
        super().__init__(f'robot_state_manager_{robot_id}')
        self._robot_id = robot_id
        ns = f'/{robot_id}'

        self._home_pose        = _make_pose(config['home_x'], config['home_y'])
        self._patrol_waypoints = _parse_waypoints(config.get('patrol_waypoints', []))
        self._patrol_idx       = 0

        # ── 상태 변수 ────────────────────────────────────────────────────
        self._state            = RobotState.IDLE
        self._goal_handle      = None
        self._pending_nav_goal = None
        self._is_docked        = False
        self._dock_initialized = False

        # ── ROS 인터페이스 ───────────────────────────────────────────────
        self._nav_client    = ActionClient(self, NavigateToPose, f'{ns}/navigate_to_pose')
        self._undock_client = self.create_client(Empty, f'{ns}/undock')
        self._state_pub     = self.create_publisher(String, f'{ns}/robot_state', 10)
        self._cmd_vel_pub   = self.create_publisher(Twist,  f'{ns}/cmd_vel',     10)

        self.create_subscription(String,      f'{ns}/cmd_state', self._on_cmd_state, 10)
        self.create_subscription(PoseStamped, f'{ns}/nav_goal',  self._on_nav_goal,  10)

        if _HAS_IROBOT:
            self.create_subscription(DockStatus,
                                     f'{ns}/dock_status', self._dock_cb, 10)
            self.create_subscription(HazardDetectionVector,
                                     f'{ns}/hazard_detection', self._hazard_cb, 10)
        else:
            self.get_logger().warn(f'[{robot_id}] irobot_create_msgs 없음 — dock/hazard 비활성화')
            self._dock_initialized = True

        self.create_timer(0.5, self._publish_state)
        self.get_logger().info(f'RobotStateManager 준비  ns={ns}')

    # ── 명령 수신 ────────────────────────────────────────────────────────
    def _on_cmd_state(self, msg: String):
        cmd = msg.data.strip()
        s   = self._state
        self.get_logger().info(f'[CMD] {cmd}  (현재={s.value})')

        if cmd == 'START_PATROL':
            if s == RobotState.IDLE:
                self._transition(RobotState.PATROL)
                self._next_patrol_goal()

        elif cmd == 'STOP_PATROL':
            if s == RobotState.PATROL:
                self._cancel_navigation()
                self._transition(RobotState.IDLE)

        elif cmd == 'INTERACT':
            if s in (RobotState.PATROL, RobotState.IDLE):
                self._cancel_navigation()
                self._transition(RobotState.INTERACTING)

        elif cmd == 'RESERVE':
            # Robot B: 핸드오버 지점으로 이동 (nav_goal을 먼저 수신해야 함)
            if s in (RobotState.PATROL, RobotState.IDLE):
                self._cancel_navigation()
                self._transition(RobotState.RESERVED)
                self._dispatch_pending_goal('RESERVE')

        elif cmd == 'START_ESCORT':
            # 사용자 에스코트 시작 (nav_goal을 먼저 수신해야 함)
            if s in (RobotState.INTERACTING, RobotState.HANDOVER_READY, RobotState.IDLE):
                self._transition(RobotState.ESCORTING)
                self._dispatch_pending_goal('START_ESCORT')

        elif cmd == 'WAIT_HANDOVER':
            # Robot A: 핸드오버 지점 도착, 정지 대기
            if s in (RobotState.ESCORTING, RobotState.IDLE):
                self._cancel_navigation()
                self._transition(RobotState.WAITING_HANDOVER)

        elif cmd == 'HANDOVER_DONE':
            # Robot A: 핸드오버 완료, 홈으로 복귀
            if s == RobotState.WAITING_HANDOVER:
                self._transition(RobotState.RETURNING)
                self._send_nav_goal(self._home_pose)

        elif cmd == 'RETURN_HOME':
            if s not in (RobotState.EMERGENCY, RobotState.UNDOCKING, RobotState.ERROR):
                self._cancel_navigation()
                self._transition(RobotState.RETURNING)
                self._send_nav_goal(self._home_pose)

        elif cmd == 'EMERGENCY':
            self._emergency_stop()

        elif cmd == 'RESET':
            if s in (RobotState.EMERGENCY, RobotState.ERROR):
                self._transition(RobotState.IDLE)

    # ── Nav goal 버퍼 ────────────────────────────────────────────────────
    def _on_nav_goal(self, msg: PoseStamped):
        self._pending_nav_goal = msg
        # ESCORTING 중 새 goal 수신 → 즉시 목적지 변경
        if self._state == RobotState.ESCORTING:
            self._cancel_navigation()
            self._send_nav_goal(msg)
            self._pending_nav_goal = None

    def _dispatch_pending_goal(self, for_cmd: str):
        if self._pending_nav_goal is not None:
            self._send_nav_goal(self._pending_nav_goal)
            self._pending_nav_goal = None
        else:
            self.get_logger().error(f'[NAV] {for_cmd}: pending nav_goal 없음 → ERROR')
            self._transition(RobotState.ERROR)

    # ── Nav2 액션 ────────────────────────────────────────────────────────
    def _next_patrol_goal(self):
        if not self._patrol_waypoints:
            self.get_logger().warn('[PATROL] 경유지 미설정')
            return
        pose = self._patrol_waypoints[self._patrol_idx % len(self._patrol_waypoints)]
        self._send_nav_goal(pose)

    def _send_nav_goal(self, pose: PoseStamped):
        if not self._nav_client.server_is_ready():
            self.get_logger().error('[NAV] 서버 미준비 → ERROR')
            self._transition(RobotState.ERROR)
            return
        goal_msg      = NavigateToPose.Goal()
        goal_msg.pose = pose
        fut = self._nav_client.send_goal_async(
            goal_msg, feedback_callback=self._feedback_cb)
        fut.add_done_callback(self._goal_response_cb)
        self.get_logger().info(
            f'[NAV] 목표 전송  ({pose.pose.position.x:.2f}, {pose.pose.position.y:.2f})')

    def _cancel_navigation(self):
        if self._goal_handle is not None:
            self._goal_handle.cancel_goal_async()
            self._goal_handle = None

    def _feedback_cb(self, feedback_msg):
        dist = feedback_msg.feedback.distance_remaining
        self.get_logger().info(f'[NAV] 잔여={dist:.2f}m', throttle_duration_sec=3.0)

    def _goal_response_cb(self, future):
        handle = future.result()
        if not handle.accepted:
            self.get_logger().error('[NAV] goal 거부 → ERROR')
            self._transition(RobotState.ERROR)
            return
        self._goal_handle = handle
        handle.get_result_async().add_done_callback(self._result_cb)

    def _result_cb(self, future):
        self._goal_handle = None
        s = self._state
        self.get_logger().info(f'[NAV] 목표 도달  (state={s.value})')

        if s == RobotState.PATROL:
            self._patrol_idx += 1
            self._next_patrol_goal()            # 순찰 계속

        elif s == RobotState.RESERVED:
            self._transition(RobotState.HANDOVER_READY)   # coordinator가 다음 단계 처리

        elif s == RobotState.ESCORTING:
            self._transition(RobotState.IDLE)             # coordinator가 다음 단계 처리

        elif s == RobotState.RETURNING:
            self._transition(RobotState.IDLE)             # coordinator가 순찰 재시작

    # ── 도킹 / 충돌 ──────────────────────────────────────────────────────
    def _dock_cb(self, msg: 'DockStatus'):
        self._is_docked = msg.is_docked
        if not self._dock_initialized:
            self._dock_initialized = True
            if self._is_docked:
                self.get_logger().info('[DOCK] 도킹 감지 → 언도킹 시작')
                self._start_undocking()
            else:
                self.get_logger().info('[DOCK] 이미 언도킹 → IDLE')
        elif self._state == RobotState.UNDOCKING and not self._is_docked:
            self.get_logger().info('[DOCK] 언도킹 완료 → IDLE')
            self._transition(RobotState.IDLE)

    def _start_undocking(self):
        self._transition(RobotState.UNDOCKING)
        if not self._undock_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().error('[UNDOCK] 서비스 없음 → IDLE 강제')
            self._transition(RobotState.IDLE)
            return
        fut = self._undock_client.call_async(Empty.Request())
        fut.add_done_callback(lambda _: self.get_logger().info('[UNDOCK] 요청 전송'))

    def _hazard_cb(self, msg: 'HazardDetectionVector'):
        for h in msg.detections:
            if h.type == HazardDetection.BUMP:
                self.get_logger().error('[HAZARD] 범퍼 감지 → EMERGENCY')
                self._emergency_stop()
                return

    def _emergency_stop(self):
        self._cancel_navigation()
        self._cmd_vel_pub.publish(Twist())
        self._transition(RobotState.EMERGENCY)

    # ── 공통 유틸 ────────────────────────────────────────────────────────
    def _transition(self, new_state: RobotState):
        if self._state == new_state:
            return
        self.get_logger().warn(f'[STATE] {self._state.value} → {new_state.value}')
        self._state = new_state

    def _publish_state(self):
        msg      = String()
        msg.data = self._state.value
        self._state_pub.publish(msg)


# ── 유틸 함수 ─────────────────────────────────────────────────────────────
def _make_pose(x: float, y: float, frame: str = 'map') -> PoseStamped:
    p = PoseStamped()
    p.header.frame_id    = frame
    p.pose.position.x    = x
    p.pose.position.y    = y
    p.pose.orientation.w = 1.0
    return p


def _parse_waypoints(flat: list) -> list:
    result = []
    for i in range(0, len(flat) - 1, 2):
        result.append(_make_pose(float(flat[i]), float(flat[i + 1])))
    return result


# ── 엔트리포인트 ──────────────────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)

    executor = MultiThreadedExecutor()
    nodes = []
    for robot_id, config in ROBOT_CONFIGS.items():
        node = RobotStateManager(robot_id, config)
        executor.add_node(node)
        nodes.append(node)

    try:
        executor.spin()
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        for node in nodes:
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
